package com.smartcane.transit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransitApplicationTests {

	@Test
	void contextLoads() {
	}

}
